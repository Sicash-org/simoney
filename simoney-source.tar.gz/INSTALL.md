Building SiMoney
================

See doc/build-*.md for instructions on building the various
elements of the SiMoney reference implementation of SiMoney.
