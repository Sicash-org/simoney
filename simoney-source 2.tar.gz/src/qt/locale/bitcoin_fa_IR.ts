<TS language="fa_IR" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Create a new address</source>
        <translation>گشایش حسابی جدید</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>جدید</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>کپی کردن حساب انتخاب شده به حافظه سیستم - کلیپ بورد</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>کپی</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>بستن</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>حذف آدرس های انتخاب شده از لیست</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>صدور داده نوار جاری به یک فایل</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>صدور</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>حذف</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>دیالوگ رمزعبور</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>رمز/پَس فرِیز را وارد کنید</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>رمز/پَس فرِیز جدید را وارد کنید</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>رمز/پَس فرِیز را دوباره وارد کنید</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>امضا و پیام</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>به روز رسانی با شبکه...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>و بازبینی</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>نمای کلی از wallet را نشان بده</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>و تراکنش</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>تاریخچه تراکنش را باز کن</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>خروج</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>از "درخواست نامه"/ application خارج شو</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>درباره و Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>نمایش اطلاعات درباره Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>و انتخابها</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>و رمزگذاری wallet</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>و گرفتن نسخه پیشتیبان از wallet</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>تغییر رمز/پَس فرِیز</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>دریافت آدرس ها</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>گرفتن نسخه پیشتیبان در آدرسی دیگر</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>رمز مربوط به رمزگذاریِ wallet را تغییر دهید</translation>
    </message>
    <message>
        <source>Bitcoin</source>
        <translation>SiMoney</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>کیف پول</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>و ارسال</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;نمایش/ عدم نمایش و</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>و فایل</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>و تنظیمات</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>و راهنما</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>نوار ابزار</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>خطا</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>روزآمد</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>در حال روزآمد سازی..</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>ارسال تراکنش</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>تراکنش دریافتی</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>wallet رمزگذاری شد و در حال حاضر از حالت قفل در آمده است</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>wallet رمزگذاری شد و در حال حاضر قفل است</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>میزان وجه:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>میزان</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>تاریخ</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>تایید شده</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>ویرایش حساب</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>و برچسب</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>حساب&amp;</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>نسخه</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>میزان استفاده:</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Error</source>
        <translation>خطا</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>فرم</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>انتخاب/آپشن</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>شبکه</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>کیف پول</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>و تایید</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>و رد</translation>
    </message>
    <message>
        <source>default</source>
        <translation>پیش فرض</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>فرم</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Bitcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>اطلاعات نمایش داده شده ممکن است روزآمد نباشد. wallet شما به صورت خودکار بعد از برقراری اتصال با شبکه simoney به روز می شود اما این فرایند هنوز تکمیل نشده است.</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>میزان</translation>
    </message>
    </context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client version</source>
        <translation>ویرایش کنسول RPC</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>شبکه</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>تعداد اتصال</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>زنجیره مجموعه تراکنش ها</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>تعداد زنجیره های حاضر</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>میزان وجه:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>و برچسب</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>پیام:</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Copy &amp;Address</source>
        <translation>کپی آدرس</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>سکه های ارسالی</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>وجوه ناکافی</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>میزان وجه:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>ارسال همزمان به گیرنده های متعدد</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>مانده حساب:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>تایید عملیات ارسال </translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>و ارسال</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>و میزان وجه</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>پرداخت و به چه کسی</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>و برچسب</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt و A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>آدرس را بر کلیپ بورد کپی کنید</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt و P</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>پیام:</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>پرداخت به:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>یادداشت:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>تا پیش از بسته شدن این پنجره کامپیوتر خود را خاموش نکنید.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>و امضای پیام </translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt و A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>آدرس را بر کلیپ بورد کپی کنید</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt و P</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>و امضای پیام </translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>این بخش جزئیات تراکنش را نشان می دهد</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>انتخابها:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>دایرکتوری داده را مشخص کن</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>command line  و JSON-RPC commands را قبول کنید</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>به عنوان daemon بک گراند را اجرا کنید و دستورات را قبول نمایید</translation>
    </message>
    <message>
        <source>The transaction amount is too small to send after the fee has been deducted</source>
        <translation>مبلغ تراکنش کمتر از آن است که پس از کسر هزینه  تراکنش قابل ارسال باشد</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>گزینه های سرویس دهنده RPC:</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>ارسال اطلاعات پیگیری/خطایابی به کنسول به جای ارسال به فایل debug.log</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>ارسال تراکنش ها به صورت بدون کارمزد در صورت امکان (پیش فرض: %u)</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>شناسه کاربری برای ارتباطاتِ JSON-RPC</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>رمز برای ارتباطاتِ JSON-RPC</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>دستور را وقتی بهترین بلاک تغییر کرد اجرا کن (%s در دستور توسط block hash جایگزین شده است)</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>لود شدن آدرسها..</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>تنظیم تعداد ریسمان ها برای سرویس دهی فراخوانی های RPC (پیش فرض: %d)</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>فایل تنظیمات را مشخص کنید (پیش فرض: %s)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>فایل pid را مشخص کنید (پیش فرض: %s)</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>وجوه ناکافی</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>لود شدن نمایه بلاکها..</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>یک گره برای اتصال اضافه کنید و تلاش کنید تا اتصال را باز نگاه دارید</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>wallet در حال لود شدن است...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>قابلیت برگشت به نسخه قبلی برای wallet امکان پذیر نیست</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>آدرس پیش فرض قابل ذخیره نیست</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>اسکنِ دوباره...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>اتمام لود شدن</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>خطا</translation>
    </message>
</context>
</TS>